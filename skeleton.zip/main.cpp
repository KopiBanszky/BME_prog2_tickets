#include <iostream>
#include "test.hpp"

//TODO: DELEGATE DEFINITIONS TO .CPP FILES

int main() {
    run_tests();

    return 0;
}
